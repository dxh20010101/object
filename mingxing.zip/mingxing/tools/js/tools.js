$(".top_l li").hover(function(){
	var $index=$(this).index(); 
	$(".show").eq($index).fadeIn().siblings().hide();
    $(this).addClass("active_lc").siblings().removeClass("active_lc");
	

},function(){

})
$(".top_l li").click(function(){
	var $index=$(this).index(); 
	$(".show").eq($index).fadeIn().siblings().hide();
    $(this).addClass("active").siblings().removeClass("active");
})